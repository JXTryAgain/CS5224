from flask import Flask,request,render_template,redirect

app = Flask(__name__)
# //绑定访问地址127.0.0.1:5000/user
@app.route("/",methods=['GET','POST'])
def login():
    if request.method =='POST':
        username = request.form['username']
        password = request.form['password']
        if username =="user" and password=="password":
            return redirect("http://www.baidu.com")
        else:
            message = "Failed Login"
            return render_template('login1.html',message=message)
    return render_template('index.html')

@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/price")
def price():
    return render_template("web02-page01.html")

@app.route("/prediction",methods=['GET','POST'])
def prediction():
    if request.method =='POST':
        town_name = request.form['town_name']
        area = request.form['area']
        lease_year = request.form['lease_year']
        storey = request.form['storey']
        type = request.form['type']
        year = request.form['year']
        print(town_name,area,lease_year,storey,type,year)
        # if username =="user" and password=="password":
        #     return redirect("http://www.baidu.com")
        # else:
        #     message = "Failed Login"
        #     return render_template('login1.html',message=message)
    return render_template("web02-page02.html")

@app.route("/about")
def about():
    return render_template("web02-page03.html")

if __name__ == '__main__':
    app.run(debug=True)
