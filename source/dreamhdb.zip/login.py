from flask import Flask, request, render_template, redirect, jsonify
import requests
import json

import os

app = Flask(__name__)

tasks = [
    {'town_name': 1,
     'area': u'Buy groceries',
     'lease_year': u'Milk, Cheese, Pizza, Fruit, Tylenol',
     'storey': 111,
     'type': 111,
     'year': 111,
     }
]


# //绑定访问地址127.0.0.1:5000/user
@app.route("/")
def login():
    return render_template('index.html')


@app.route("/index")
def index():
    return render_template("index.html")


@app.route("/price")
def price():
    return render_template("web02-page01.html")


@app.route("/prediction", methods=['GET', 'POST'])
def prediction():
    if request.method == 'POST':
        headers = {
            'content-type': 'application/json',
        }
        # tasks[0]['town_name'] = request.form['town_name']
        # tasks[0]['area'] = request.form['area']
        # tasks[0]['lease_year'] = request.form['lease_year']
        # tasks[0]['storey'] = request.form['storey']
        # tasks[0]['type'] = request.form['type']
        # tasks[0]['year'] = request.form['year']

        data = '{"town_name": "'+str(request.form['town_name'])+'", "area": '+str(request.form['area'])+', "lease_year": '+str(request.form['lease_year'])+', "storey": '+str(request.form['storey'])+', "type": '+str(request.form['type'])+', "year": '+str(request.form['year'])+'}'

        response = requests.post('https://ed256ki211.execute-api.us-east-1.amazonaws.com/dev/hdb', headers=headers,
                                 data=data)
        tempJson=json.loads(response.text)
        tempAns=tempJson["output"].rstrip("]")
        tempAns = tempAns.lstrip("[")
        print(tempAns)
        tempAns="Predict Price is "+tempAns
        return render_template("web02-page02.html", message=tempAns)



        # headers = {
        #     'content-type': 'application/json',
        # }
        #
        # data = '{"town_name": "JURONG WEST", "area": 100, "lease_year": 1999, "storey": 10, "type": 3, "year": 1996}'
        #
        # response = requests.get('https://ed256ki211.execute-api.us-east-1.amazonaws.com/dev/hdb', headers=headers,
        #                          data=data)
        # command="curl -v POST 'https://ed256ki211.execute-api.us-east-1.amazonaws.com/dev/hdb' -H 'content-type: application/json' -d '{\"town_name\": \"JURONG WEST\", \"area\": 100, \"lease_year\": 1999, \"storey\": 10, \"type\": 3, \"year\": 1996}'"
        # # command="ls"
        # r=os.popen(command)
        # info=r.readlines()

        # print("execute")
        # tasks[0]['town_name']=town_name
        # print(town_name,area,lease_year,storey,type,year)
        # if username =="user" and password=="password":
        #     return redirect("http://www.baidu.com")
        # else:
        #     message = "Failed Login"
        #     return render_template('login1.html',message=message)
        # print(response.text)
    return render_template("web02-page02.html")


# @app.route('https://ed256ki211.execute-api.us-east-1.amazonaws.com/dev/hdb', methods=['GET'])
# def get_tasks():
#     ans=jsonify({'tasks': tasks})
#     print(ans)
#     return ans


@app.route("/about")
def about():
    return render_template("web02-page03.html")


if __name__ == '__main__':
    app.run(debug=True)
